
<input type="text" name="<?=$name ?>" value="<?=$value ?>">
