<?PHP

// global $wpdb;
//
// $wpdb->query('
//   CREATE TABLE '.$wpdb->prefix.'sp_locations (
//     id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
//     title VARCHAR(255) NOT NULL,
//     lat VARCHAR(255) NOT NULL,
//     lng VARCHAR(255) NOT NULL,
//     type VARCHAR(255) NOT NULL,
//     street VARCHAR(255) NOT NULL,
//     house_number VARCHAR(255) NOT NULL,
//     postcode VARCHAR(255) NOT NULL,
//     suburb VARCHAR(255) NOT NULL,
//     opening_hours TEXT NOT NULL,
//     solution TEXT NOT NULL,
//     description TEXT NOT NULL,
//     rsa_public_key TEXT NOT NULL,
//     email VARCHAR(255) NOT NULL,
//     telephone VARCHAR(255) NOT NULL,
//     contact_person TEXT NOT NULL,
//     images TEXT NOT NULL,
//     created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//     updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
//   )
// ');
