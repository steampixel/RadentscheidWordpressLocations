
<textarea name="<?=$name ?>"><?=$value ?></textarea>
